---
name: translation-localization
description: "다국어 번역, 현지화, 문화 적응, 용어 관리를 에이전트 팀이 협업하여 수행하는 풀 번역 파이프라인. '이 문서 번역해줘', '영어로 번역', '일본어 현지화', '번역 검수해줘', '용어집 만들어줘', '다국어 지원', '앱 현지화', '웹사이트 번역', '마케팅 자료 번역', '기술 문서 번역' 등 번역·현지화 전반에 이 스킬을 사용한다. 기존 번역이 있는 경우에도 품질 검증이나 현지화 적용을 지원한다. 단, 실시간 통역, CAT 도구(Trados/MemoQ) 직접 연동, DTP(Desktop Publishing) 작업은 이 스킬의 범위가 아니다."
---

# Translation & Localization — 번역·현지화 풀 파이프라인

다국어 번역·현지화·문화적응·용어관리를 에이전트 팀이 협업하여 한 번에 수행한다.

## 실행 모드

**에이전트 팀** — 5명이 SendMessage로 직접 통신하며 교차 검증한다.

## 에이전트 구성

| 에이전트 | 파일 | 역할 | 타입 |
|---------|------|------|------|
| translator | `.claude/agents/translator.md` | 원문 분석, 1차 번역 | general-purpose |
| localizer | `.claude/agents/localizer.md` | 문화 적응, 형식 현지화 | general-purpose |
| terminology-manager | `.claude/agents/terminology-manager.md` | 용어집 구축, 일관성 관리 | general-purpose |
| style-harmonizer | `.claude/agents/style-harmonizer.md` | 톤앤보이스 통일, 문체 조정 | general-purpose |
| quality-reviewer | `.claude/agents/quality-reviewer.md` | MQM 기반 품질 검증 | general-purpose |

## 워크플로우

### Phase 1: 준비 (오케스트레이터 직접 수행)

1. 사용자 입력에서 추출한다:
   - **원문**: 번역할 텍스트 또는 파일
   - **원문 언어 / 타깃 언어**: 번역 방향
   - **도메인** (선택): IT/의료/법률/마케팅/일반
   - **타깃 시장** (선택): 구체적 국가/지역
   - **스타일 가이드** (선택): 브랜드 톤, 격식 수준
   - **기존 용어집** (선택): 이전 프로젝트 용어집
2. `_workspace/` 디렉토리를 프로젝트 루트에 생성한다
3. 입력을 정리하여 `_workspace/00_input.md`에 저장한다
4. 기존 파일이 있으면 `_workspace/`에 복사하고 해당 Phase를 건너뛴다
5. 요청 범위에 따라 **실행 모드를 결정**한다 (아래 "작업 규모별 모드" 참조)

### Phase 2: 팀 구성 및 실행

팀을 구성하고 작업을 할당한다. 작업 간 의존 관계는 다음과 같다:

| 순서 | 작업 | 담당 | 의존 | 산출물 |
|------|------|------|------|--------|
| 1a | 원문 분석·번역 전략 | translator | 없음 | `_workspace/01_source_analysis.md` |
| 1b | 용어집 구축 | terminology | 없음 | `_workspace/02_terminology.md` |
| 2 | 1차 번역 | translator | 작업 1b | `_workspace/03_translation.md` |
| 3 | 현지화 적용 | localizer | 작업 2 | `_workspace/04_localization.md` |
| 3+ | 스타일 통일 | harmonizer | 작업 3 | `_workspace/04_localization.md` 업데이트 |
| 4 | 품질 검증 | reviewer | 작업 2, 3, 3+ | `_workspace/05_review_report.md` |

작업 1a(원문 분석)와 1b(용어집 구축)는 **병렬 실행**한다.

**팀원 간 소통 흐름:**
- terminology 완료 → translator에게 용어집 전달 (번역 시작 전 필수)
- translator 완료 → localizer에게 1차 번역문 + 문화적 판단 필요 목록 전달
- localizer 완료 → harmonizer에게 현지화 적용문 + 톤 조정 필요 부분 전달
- harmonizer 완료 → reviewer에게 스타일 적용 결과 전달
- reviewer는 모든 산출물을 교차 검증. 🔴 필수 수정 발견 시 해당 에이전트에게 수정 요청 → 재작업 → 재검증 (최대 2회)

### Phase 3: 통합 및 최종 산출물

리뷰어의 보고서를 기반으로 최종 산출물을 정리한다:

1. `_workspace/` 내 모든 파일을 확인한다
2. 리뷰 보고서의 🔴 필수 수정이 모두 반영되었는지 확인한다
3. 최종 요약을 사용자에게 보고한다:
   - 원문 분석 — `01_source_analysis.md`
   - 용어집 — `02_terminology.md`
   - 번역문 — `03_translation.md`
   - 현지화 결과 — `04_localization.md`
   - 품질 보고서 — `05_review_report.md`

## 작업 규모별 모드

사용자 요청의 범위에 따라 투입 에이전트를 조절한다:

| 사용자 요청 패턴 | 실행 모드 | 투입 에이전트 |
|----------------|----------|-------------|
| "이 문서 번역해줘", "풀 현지화" | **풀 파이프라인** | 5명 전원 |
| "간단히 번역만 해줘" | **번역 모드** | translator + terminology + reviewer |
| "이 번역 현지화해줘" (기존 번역) | **현지화 모드** | localizer + harmonizer + reviewer |
| "용어집만 만들어줘" | **용어 모드** | terminology 단독 |
| "이 번역 검수해줘" | **리뷰 모드** | reviewer 단독 |

**기존 파일 활용**: 사용자가 기존 번역, 용어집 등을 제공하면, 해당 파일을 `_workspace/`에 복사하고 해당 단계를 건너뛴다.

## 데이터 전달 프로토콜

| 전략 | 방식 | 용도 |
|------|------|------|
| 파일 기반 | `_workspace/` 디렉토리 | 주요 산출물 저장 및 공유 |
| 메시지 기반 | SendMessage | 실시간 핵심 정보 전달, 수정 요청 |
| 태스크 기반 | TaskCreate/TaskUpdate | 진행 상황 추적, 의존 관계 관리 |

파일명 컨벤션: `{순번}_{에이전트}_{산출물}.{확장자}`

## 에러 핸들링

| 에러 유형 | 전략 |
|----------|------|
| 원문 언어 판별 불가 | 자동 감지 결과 제시 + 사용자 확인 요청 |
| 전문 도메인 지식 부족 | 웹 검색으로 용례 조사, 번역 노트에 불확실성 명시 |
| 문화적 등가물 부재 | 원문 유지 + 괄호 설명 방식으로 처리 |
| 에이전트 실패 | 1회 재시도 → 실패 시 해당 단계 생략, 리뷰 보고서에 명시 |
| 리뷰에서 🔴 발견 | 해당 에이전트에 수정 요청 → 재작업 → 재검증 (최대 2회) |

## 테스트 시나리오

### 정상 흐름
**프롬프트**: "이 마케팅 웹사이트 콘텐츠를 일본어로 번역·현지화해줘. 타깃은 일본 20~30대" + 원문 파일
**기대 결과**:
- 원문 분석: 마케팅 도메인, 캐주얼 톤, 문화 참조 목록
- 용어집: 브랜드명 DNT, 마케팅 용어 일본어 매핑
- 번역문: 자연스러운 일본어 번역, 번역 노트 포함
- 현지화: 일본 형식(날짜/통화/도량형), 문화적 레퍼런스 대체
- 품질 보고서: MQM 점수, 오류 분류, 정합성 매트릭스

### 기존 파일 활용 흐름
**프롬프트**: "이 영어 번역을 검수하고 현지화 개선해줘" + 기존 번역 파일
**기대 결과**:
- 기존 번역을 `_workspace/03_translation.md`로 복사
- 현지화 모드: localizer + harmonizer + reviewer 투입
- translator, terminology는 건너뜀 (단, reviewer가 용어 일관성은 확인)

### 에러 흐름
**프롬프트**: "이 기술 문서 번역해줘, 언어는 스페인어"
**기대 결과**:
- 타깃 시장 미지정 → 스페인(유럽 스페인어) 기본값 적용
- 기술 도메인 용어 웹 검색으로 표준 용어 확인
- 리뷰 보고서에 "타깃 시장 가정: 스페인" 명시

## 에이전트별 확장 스킬

개별 에이전트의 도메인 전문성을 강화하는 확장 스킬:

| 스킬 | 대상 에이전트 | 역할 |
|------|-------------|------|
| `translation-quality-mqm` | quality-reviewer | MQM 오류 분류, 심각도 체계, 품질 점수 산출 공식 |
| `cultural-adaptation-guide` | localizer | 시장별 형식 변환, 문화 금기, 관용구 대체 전략 |
